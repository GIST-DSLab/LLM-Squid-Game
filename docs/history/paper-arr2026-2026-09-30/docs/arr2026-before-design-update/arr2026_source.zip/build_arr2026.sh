#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build/arr2026 dist
for lang in en ko; do
  latexmk -xelatex -interaction=nonstopmode -halt-on-error \
    -outdir=build/arr2026 "${lang}_arr2026.tex"
  cp "build/arr2026/${lang}_arr2026.pdf" "dist/${lang}_arr2026.pdf"
done
