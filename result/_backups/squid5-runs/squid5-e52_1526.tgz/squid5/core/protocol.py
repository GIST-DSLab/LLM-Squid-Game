"""Parsers for every answer line. A parser returns a value or raises FormatError.

Keys are matched only at the start of a line (after markdown decoration),
never mid-line: the team-wallet smokes showed a REASON sentence containing
"stop: X" being read as a STOP line when mid-line matches were allowed.
The v6 PLAN parser (STAY / SHOW / GIVE / REQUEST) is gone with its session (tag e52-v65).
"""

from __future__ import annotations

import re

from .channel import EXAMPLE
from .puzzle import ACTIONS


class FormatError(ValueError):
    pass


def field(text: str, key: str, required: bool = True, last: bool = False) -> str | None:
    lines = text.splitlines()
    for line in reversed(lines) if last else lines:
        m = re.match(rf"^[\s*_`>#-]*{key}[*_`]*\s*:\s*(.*)$", line, flags=re.IGNORECASE)
        if m:
            return m.group(1).strip().strip("*_`").strip()
    if required:
        raise FormatError(f"missing {key} line")
    return None


def whole(value: str, key: str) -> int:
    m = re.match(r"[<\s]*(\d[\d,]*)(\.\d)?", value)
    if not m or m.group(2):  # "0.35" must not be read as 0
        raise FormatError(f"{key} is not a whole number: {value!r}")
    return int(m.group(1).replace(",", ""))


def _acts(value: str, n: int) -> list[str]:
    acts = [a.strip().strip("<>[]'\"*_`.").lower() for a in re.split(r"[,\s]+", value) if a.strip("<>[]*_` .")]
    if len(acts) != n or any(a not in ACTIONS for a in acts):
        raise FormatError(f"need {n} actions from {ACTIONS}: {value!r}")
    return acts


def parse_actions(text: str, n: int) -> list[str]:
    """The answer: a last line that is exactly the n actions (``stay``, ``go_left, jump``), or whose text after its
    last arrow is (``... -> go_right.``), wins over any earlier ``Action:`` line of working; otherwise the later of
    the last ``ACTIONS:`` / ``ANSWER:`` line (or a numbered list after it) and the last ``<action>...</action>`` tag.
    A winning tag must hold exactly the n actions: no arrow is read inside it and it never falls back."""
    tag = r"<\s*(actions?|answers?)\s*>(.*?)<\s*/\s*\1\s*>"
    lines = [x for x in text.strip().splitlines() if x.strip()]
    if lines:
        wrapped = re.fullmatch(r"[\s*_`]*" + tag + r"[\s*_`.]*", lines[-1], flags=re.I)
        if wrapped:
            return _acts(wrapped.group(2), n)
        try:
            return _acts(re.split(r"->|→", lines[-1])[-1], n)
        except FormatError:
            pass
    label = r"(?:ACTIONS?|ANSWERS?)[*_`]*\s*:"
    tags = list(re.finditer(tag, text, flags=re.I | re.S))
    labels = list(re.finditer(rf"^[\s*_`>#-]*{label}", text, flags=re.I | re.M))
    if tags and (not labels or tags[-1].start() > labels[-1].start()):  # the later field wins, whatever it holds
        return _acts(tags[-1].group(2), n)
    if not labels:  # no answer field anywhere (A26): a first line of exactly the n actions, else no answer
        return _acts(lines[0] if lines else "", n)
    value = field(text, "(?:ACTIONS?|ANSWERS?)", required=False, last=True)  # the answer line, not "Action:" working
    if value == "":  # "ACTIONS:" followed by a numbered list, one action per line
        tail = re.split(label, text, flags=re.IGNORECASE)[-1]
        value = ",".join(re.findall(r"^\s*\d+[.)]\s*(\w+)", tail, flags=re.MULTILINE))
    return _acts(value or "", n)


_TALK = re.compile(r"^[\s*_`>#-]*(TO|OFFER)\b[*_`]*\s*(.*)$", re.I)
_IDS = re.compile(r"(ACCEPT|WITHDRAW|REJECT)\s+(\d+\.\d+(?:\s*,\s*\d+\.\d+)*)", re.I)
_LEG = r"(?:(\d[\d,]*)\s*TOKENS?|((?:(?:YOUR|MY|THEIR|ITS|HIS|HER|AN|THE|ONE)\s+)?EXAMPLE)|(NOTHING))"


def _offer(body: str) -> tuple | None:
    """``YOU GIVE <leg>; I GIVE <leg>`` -> (you_give, i_give): an int, EXAMPLE or None; None if unreadable, a token leg
    is 0, or both legs are NOTHING. The side a leg stands on says whose example it is, so its possessive is not read:
    the v9-talk Luna runs wrote swaps as "YOU GIVE MY EXAMPLE; I GIVE MY EXAMPLE" or "... I GIVE THEIR EXAMPLE"."""
    m = re.fullmatch(rf"YOU\s+GIVE\s+{_LEG}\s*[;,]?\s*I\s+GIVE\s+{_LEG}", re.sub(r"[<>*_`]", "", body).strip(" ."),
                     flags=re.I)
    if not m:
        return None
    legs = []
    for n, example, _ in (m.group(1, 2, 3), m.group(4, 5, 6)):
        if n is not None and int(n.replace(",", "")) > 0:
            legs.append(int(n.replace(",", "")))
        elif n is not None:
            return None
        else:
            legs.append(EXAMPLE if example else None)
    return None if legs == [None, None] else tuple(legs)


def _to_names(head: str, known: list[str]) -> list[str] | None:
    """The agent names before a TO / OFFER colon (``agent 11`` / ``agent11`` read as ``agent-11``), or None when any
    part of a comma / "and" list is not a name: a known one or one shaped like ``agent-<number>``."""
    names = []
    for part in re.split(r"\s*(?:,|&|\band\b)\s*", re.sub(r"[*_`]", "", head).strip(), flags=re.I):
        name = re.sub(r"^agent[\s-]?(?=\d+$)", "agent-", part.strip().lower())
        if not name or (name not in known and not re.fullmatch(r"agent-\d+", name)):
            return None
        names.append(name)
    return names


def parse_talk(text: str, present: list[str], known: list[str], you: str, reject: bool = False,
               exit_reason: bool = False, examples: bool = True) -> dict:
    """5.2 TALK: TO / OFFER / ACCEPT / WITHDRAW (and, with ``reject``, REJECT) lines in order, and EXIT / DONE alone on
    a line (prose such as "Exit strategy: ..." is neither). A TO / OFFER line is a key line only when what stands before
    its colon is an agent name (one in ``known`` or shaped like ``agent-7``), so "To summarize: ..." is prose; a line
    naming several agents is dropped (one agent per TO line). An ACCEPT / WITHDRAW / REJECT line counts only when the
    whole line (markdown stripped) is the key word and offer ids, so a quoted "Accept 1.2 if you want" is prose. Any
    other line belongs to the open message (a TO line's, until the next key line; blank lines at its ends are cut) or
    is ignored. Never raises: a line that cannot be carried out, or a message left empty, is kept in ``dropped`` with
    the reason; a reply with nothing usable counts as DONE and gets a ``format_error``. ``present`` = the other agents
    taking part. ``exit_reason``: ``EXIT: <reason>`` is EXIT too (the word before the colon exactly EXIT, so "Exit
    strategy: ..." is not); the reason is kept in ``exit_reason`` (None for a bare EXIT), never required. ``examples``
    off (5.2 v14 public examples): an OFFER with an EXAMPLE leg is dropped like any line that cannot be carried out."""
    out = {"to": [], "offers": [], "accepts": [], "withdraws": [], "rejects": [], "exit": False, "done": False,
           "dropped": [], "format_error": None} | ({"exit_reason": None} if exit_reason else {})
    msg, head = None, ""

    def flush():
        if msg is not None:
            body = msg["text"].strip("\n")
            if re.search(r"(^|\s)DONE\.?$", body):  # "... let's swap. DONE" ends the reply's TALK too
                body, out["done"] = re.sub(r"\s*DONE\.?$", "", body), True
            if body:
                out["to"].append({"dst": msg["dst"], "text": body})
            else:
                out["dropped"].append(f"{head}: empty message")

    for line in text.splitlines():
        bare = re.sub(r"[*_`]", "", line).strip().strip("#>-. ")
        why = re.fullmatch(r"EXIT\s*:\s*(.*)", bare, flags=re.I | re.S) if exit_reason else None
        if bare.upper() in ("EXIT", "DONE") or why:
            flush()
            out["exit" if why else bare.lower()], msg = True, None
            if why:
                out["exit_reason"] = why.group(1).strip() or None
            continue
        ids = _IDS.fullmatch(bare)
        ids = ids if ids and (reject or ids.group(1).upper() != "REJECT") else None
        m = None if ids else _TALK.match(line)
        t = re.match(r"([^:]+?)\s*:[*_`]*\s*(.*)$", m.group(2), flags=re.S) if m else None
        names = _to_names(t.group(1), known) if t else None
        if not (ids or names):
            if msg is not None:
                msg["text"] += "\n" + line.strip()
            continue
        flush()
        msg = None
        if ids:
            out[ids.group(1).lower() + "s"] += re.findall(r"\d+\.\d+", ids.group(2))
            continue
        key, name = m.group(1).upper(), names[0]
        why = ("one agent per TO line" if len(names) > 1 else
               "not another agent" if name not in known or name == you else
               "that agent is not taking part" if name not in present else None)
        legs = None if why or key == "TO" else _offer(t.group(2))
        why = why or ("not 'YOU GIVE ...; I GIVE ...'" if key == "OFFER" and legs is None else
                      "an offer gives tokens or nothing" if key == "OFFER" and not examples and EXAMPLE in legs else None)
        if why:
            out["dropped"].append(f"{line.strip()}: {why}")
        elif key == "TO":
            msg, head = {"dst": name, "text": t.group(2).strip()}, line.strip()
        else:
            out["offers"].append({"dst": name, "you_give": legs[0], "i_give": legs[1]})
    flush()
    if not any(out[k] for k in ("to", "offers", "accepts", "withdraws", "rejects", "exit", "done")):
        out["done"], out["format_error"] = True, "no usable TALK line"
    return out


_GA = re.compile(r"(agent[\s-]?\d+)\s*:?\s*(\d[\d,]*)\s*(?:tokens?)?\s*(?::\s*(.*))?", re.I | re.S)


def parse_give_ask(text: str, present: list[str], known: list[str], you: str, exit_reason: bool = False) -> dict:
    """5.2 v14b TALK (``transfers: give_ask``): ``GIVE <agent> <n>: <sentence>`` and ``ASK <agent> <n>: <sentence>``
    lines (one agent and a whole number above zero each; the sentence may be left out) and EXIT / DONE alone on a line,
    as in :func:`parse_talk`. A TO / OFFER / ACCEPT / WITHDRAW / REJECT line, or a GIVE / ASK line that cannot be
    carried out, is kept in ``dropped`` with the reason; any other line is ignored. Never raises: a reply with nothing
    usable counts as DONE and gets a ``format_error``. ``present`` = the other agents taking part."""
    out = {"gives": [], "asks": [], "exit": False, "done": False, "dropped": [], "format_error": None} | (
        {"exit_reason": None} if exit_reason else {})
    for line in text.splitlines():
        bare = re.sub(r"[*`]", "", line).strip().strip("#>-. _")
        why = re.fullmatch(r"EXIT\s*:\s*(.*)", bare, flags=re.I | re.S) if exit_reason else None
        if bare.upper() in ("EXIT", "DONE") or why:
            out["exit" if why else bare.lower()] = True
            if why:
                out["exit_reason"] = why.group(1).strip() or None
        elif m := re.match(r"(GIVE|ASK)\s+(.*)$", bare, re.I | re.S):
            b = _GA.fullmatch(m.group(2).strip())
            name = (_to_names(b.group(1), known) or [None])[0] if b else None
            n = int(b.group(2).replace(",", "")) if b else 0
            why = ("not '<agent> <n>: <sentence>'" if not name else "not another agent" if name not in known or
                   name == you else "that agent is not taking part" if name not in present else
                   "the amount must be above zero" if not n else None)
            if why:
                out["dropped"].append(f"{line.strip()}: {why}")
            else:
                out[m.group(1).lower() + "s"].append({"dst": name, "amount": n, "text": (b.group(3) or "").strip()})
        elif re.match(r"(TO|OFFER|ACCEPT|WITHDRAW|REJECT)\b", bare, re.I):
            out["dropped"].append(f"{line.strip()}: only GIVE, ASK, EXIT and DONE lines are read")
    if not any(out[k] for k in ("gives", "asks", "exit", "done")):
        out["done"], out["format_error"] = True, "no usable TALK line"
    return out


_MOVE = re.compile(r"(GIVE|ASK)\s+(?:agent[\s-]?\d+\s*:?\s*)?(\d[\d,]*)\s*(?:tokens?)?\s*(?::\s*(.*))?|(SAY|LEAVE)\b\s*:?\s*(.*)",
                   re.I | re.S)


def parse_chat(text: str, exit_reason: bool = False) -> dict:
    """5.2 v14c one chat reply: ONE of ``GIVE <n>: <sentence>`` / ``ASK <n>: <sentence>`` (a partner name before n is
    read too) / ``SAY: <sentence>`` / ``LEAVE: <sentence>``, and an EXIT line (``EXIT: <reason>`` with *exit_reason*).
    The first such line counts; a second one and any other non-empty line are kept in ``dropped`` with the reason. A
    reply with no move counts as LEAVE (with a ``format_error`` unless it held EXIT). Never raises."""
    out = {"kind": None, "amount": 0, "text": "", "exit": False, "dropped": [], "format_error": None} | (
        {"exit_reason": None} if exit_reason else {})
    for line in text.splitlines():
        bare = re.sub(r"[*`]", "", line).strip().strip("#>-. _")
        why = re.fullmatch(r"EXIT\s*(?::\s*(.*))?", bare, flags=re.I | re.S)
        m = None if why else _MOVE.fullmatch(bare)
        if why:
            out["exit"] = True
            if exit_reason:
                out["exit_reason"] = (why.group(1) or "").strip() or None
        elif m and out["kind"] is None and (m.group(4) or int(m.group(2).replace(",", ""))):
            out.update(kind=(m.group(1) or m.group(4)).lower(), amount=int((m.group(2) or "0").replace(",", "")),
                       text=(m.group(3) if m.group(1) else m.group(5) or "").strip())
        elif bare:
            out["dropped"].append(f"{line.strip()[:200]}: " + ("one move per reply" if m and out["kind"] else
                                                                "not GIVE, ASK, SAY, LEAVE or EXIT"))
    if out["kind"] is None:
        out["kind"], out["format_error"] = "leave", None if out["exit"] else "no GIVE, ASK, SAY or LEAVE line"
    return out


def parse_belief(text: str) -> dict:
    """5.2 v14d: the last ``BELIEF:`` line, one whole percentage per action in any order ('%' allowed), summing to 100;
    a sum in 90..110 is normalised. Never raises; ``belief`` is None with ``belief_error`` saying why."""
    v = field(text, "BELIEF", required=False, last=True)
    pairs = re.findall(r"([a-z_]+)\s*[:=]?\s*(\d+)\s*%?", (v or "").lower())
    raw = {a: int(p) for a, p in pairs if a in ACTIONS}
    total = sum(raw.values())
    why = ("no BELIEF line" if v is None else "not one whole percentage for each action" if len(raw) != len(ACTIONS)
           or len(pairs) != len(ACTIONS) else f"the percentages sum to {total}" if not 90 <= total <= 110 else None)
    return {"belief": None if why else {a: raw[a] / total for a in ACTIONS}, "belief_raw": raw or None,
            "belief_sum": total if raw else None, "belief_error": why}


def parse_decision(text: str) -> dict:
    """5.2 v14e: the last ``DECISION: GIVE <n>: <sentence>`` line (n >= 0; the prefix may be left out). Never raises:
    an unreadable reply is GIVE 0 with a ``format_error``."""
    found = re.findall(r"^[\s*_`>#-]*(?:DECISION[*_`]*\s*:\s*)?GIVE[*_`]*\s+(\d[\d,]*)\s*(?:tokens?)?\s*(?::\s*(.*))?$",
                       text, re.I | re.M)
    n, say = found[-1] if found else ("0", "")
    return {"amount": int(n.replace(",", "")), "text": say.strip(" *_`"),
            "format_error": None if found else "no DECISION: GIVE <n> line"}


def parse_solve(text: str, n: int) -> list[str] | str:
    """5.2 SOLVE: a last line of PASS (``ACTIONS: PASS`` too) is a pass; otherwise the answer, as ``parse_actions``."""
    lines = [x for x in text.strip().splitlines() if x.strip()]
    if lines and re.fullmatch(r"[\s*_`>#-]*(?:ACTIONS?[*_`]*\s*:\s*)?[*_`]*PASS[\s*_`.]*", lines[-1], flags=re.I):
        return "PASS"
    return parse_actions(text, n)


def parse_effort(text: str) -> str:
    """5.0: the last ``effort: low|high`` line; a reply that is only the level also counts."""
    found = re.findall(r"^[\s*_`>#-]*effort[*_`]*\s*[:=][\s*_`]*(low|high)\b", text, flags=re.I | re.M)
    bare = text.strip().strip("*_`.").lower()
    if found or bare in ("low", "high"):
        return found[-1].lower() if found else bare
    raise FormatError("missing effort: low|high line")

def parse_move(text: str) -> dict:
    return {"move": whole(field(text, "MOVE"), "MOVE"), "reason": field(text, "REASON", False)}


def ask(provider, system: str, user: str, cap: int, parse, retries: int) -> dict:
    """One uncharged question (5.1 scenes): the same input is re-asked on a format error."""
    error, reply = None, None
    for attempt in range(1, retries + 2):
        reply = provider.complete([{"role": "system", "content": system}, {"role": "user", "content": user}], cap)
        try:
            return {"parsed": parse(reply.text), "format_error": None, "attempts": attempt,
                    "out_tokens": reply.out_tokens, "text": reply.text, "thinking": reply.thinking}
        except FormatError as err:
            error = str(err)
    return {"parsed": None, "format_error": error, "attempts": retries + 1, "out_tokens": reply.out_tokens,
            "text": reply.text, "thinking": reply.thinking}
